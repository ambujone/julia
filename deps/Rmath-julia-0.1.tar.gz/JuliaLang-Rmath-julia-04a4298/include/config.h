#ifndef _CONFIG_H_

#define _CONFIG_H_

#include <limits.h>

#endif /* _CONFIG_H_ */
