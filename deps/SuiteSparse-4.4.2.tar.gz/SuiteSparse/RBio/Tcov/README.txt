RBio statement coverage test.
Unix (Mac OS X, Linux, or Solaris) required.
To run, type "make"

Timothy A. Davis, http://www.suitesparse.com
